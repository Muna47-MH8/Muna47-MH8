public class NextAIInc {

    // Method to calculate and print the total weekly pay or display error messages
    public void calculatePay(double basePay, int hoursWorked) {
        // Check if base pay is below the minimum rate
        if (basePay < 30000) {
            System.out.println("Error: Base pay must not be less than UGX 30,000/hour.");
            return;
        }

        // Check if hours worked exceed the maximum limit
        if (hoursWorked > 72) {
            System.out.println("Error: Hours worked must not exceed 72 hours per week.");
            return;
        }

        // Calculate regular and overtime pay
        double totalPay;
        if (hoursWorked <= 48) {
            totalPay = hoursWorked * basePay; // All hours are regular hours
        } else {
            int regularHours = 48;
            int overtimeHours = hoursWorked - 48;
            totalPay = (regularHours * basePay) + (overtimeHours * basePay * 2); // Overtime pay
        }

        // Print the total pay
        System.out.printf("Total weekly pay: UGX %.2f%n", totalPay);
    }

    public static void main(String[] args) {
        // Create an instance of NextAIInc
        NextAIInc nextAI = new NextAIInc();

        // Test case 1: Contractor A
        System.out.println("Contractor A:");
        nextAI.calculatePay(30000, 51);

        // Test case 2: Contractor B
        System.out.println("\nContractor B:");
        nextAI.calculatePay(20000, 40);

        // Test case 3: Contractor C
        System.out.println("\nContractor C:");
        nextAI.calculatePay(35000, 96);
    }
}
